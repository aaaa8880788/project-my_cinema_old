module.exports = {
  jwtSecretKey: 'Welcom ^_^',
  webJwtSecretKey: 'I am web jwt'
}